package examples.map;

import graph.Graph;

import java.util.ArrayList;
import java.util.List;

/**
 *
 *  @author DEI-ESINF
 *
 */
public class Promotion {

              
}
